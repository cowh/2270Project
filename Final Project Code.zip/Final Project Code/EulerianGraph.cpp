#include "EulerianGraph.hpp"
#include "Stack.cpp"

using namespace std;

void EulerianGraph::addVertex(string name)
{
	bool found = false;
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].name == name)
		{
			found = true;
			break;
		}
	}
	if(found == false)
	{
		vertex v;
		v.name = name;
		vertices.push_back(v);
	}
}

void EulerianGraph::addEdge(string startV, string endV, int weight)
{
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].name == startV)
		{
			for(int j = 0; j < vertices.size(); j++)
			{
				if(vertices[j].name == endV && i != j)
				{
					adjVertex e;
					e.v = &vertices[j];
					e.weight = weight;
					vertices[i].adj.push_back(e);
				}
			}
		}
	}
}

int EulerianGraph::countEdges()
{
	int odd = 0;
	int count;
	for(int i = 0; i < vertices.size(); i++)
	{
		count = 0;
		vertex v = vertices[i];
		for(int j = 0; j < v.adj.size(); j++)
		{
			count++;
		}
		if(count%2 != 0)
			odd++;
	}
	return odd;
}

bool EulerianGraph::isConnected(string name)
{
	bool flag = true;
	vertex find = search(name);
	find.visited = true;
	find.distance = 0;
	Stack s;
	s.push(find);
	while(!s.isEmpty())
	{
		vertex popped = s.pop();
		for(int i = 0; i < popped.adj.size(); i++)
		{
			if(!popped.adj[i].v -> visited)
			{
				popped.adj[i].v -> visited = true;
				s.push(*popped.adj[i].v);
			}
		}
	}
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].visited == false)
			flag = false;
	}
	return flag;
}

bool EulerianGraph::isEulerian(EulerianGraph g, int odd, string name)
{
	if(g.isConnected(name))
	{
		cout << "Graph is not connected" << endl;
		return false;
	}
	if(odd > 2)
	{
		cout << "Graph is not Eulerian" << endl;
		return false;
	}
	else if(odd == 2)
	{
		cout << "Graph contains an Euler Path" << endl;
		return true;
	}
	else if(odd == 0)
	{
		cout << "Graph contains an Euler Circuit" << endl;
		return true;
	}
	else
	{
		cout << "Graph is not Eulerian" << endl;
		return false;
	}
}

void EulerianGraph::printGraph(EulerianGraph g)
{
	for(int i = 0; i < vertices.size(); i++)
	{
		if(i < vertices.size()-1)
		{
			cout << vertices[i].name << " - ";
		}
		else
			cout << vertices[i].name;
	}
	cout << endl;
}

vertex EulerianGraph::search(string name)
{
	vertex v;
	v.name = "";
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].name == name)
			return vertices[i];
	}
	cout << "Node not found" << endl;
	return v;
}