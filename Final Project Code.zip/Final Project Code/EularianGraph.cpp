#include "EularianGraph.hpp"

using namespace std;

void EulerianGraph::addVertex(int value)
{
	bool found = false;
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].key == value)
		{
			found = true;
			break;
		}
	}
	if(found == false)
	{
		vertex v;
		v.key = value;
		vertices.push_back(v);
		cout << "vertices updated" << endl;
	}
}

void EulerianGraph::addEdge(int startV, int endV, int weight)
{
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].key == startV)
		{
			for(int j = 0; j < vertices.size(); j++)
			{
				if(vertices[j].key == endV && i != j)
				{
					edge e;
					e.v = &vertices[j];
					e.weight = weight;
					vertices[i].adj.push_back(e);
				}
			}
		}
	}
}

void EulerianGraph::rmVertex(int value)
{

}

void EulerianGraph::rmEdge(int startV, int endV)
{

}

bool EulerianGraph::isEulerianPath()
{
	return true;
}

bool EulerianGraph::isEulerianCircuit()
{
	return true;
}

void EulerianGraph::printGraph()
{
	for(int i = 0; i < vertices.size(); i++)
	{
		if(i < vertices.size()-1)
		{
			cout << vertices[i].key << " -> ";
		}
		else
			cout << vertices[i].key;
	}
}

void EulerianGraph::printEulerian()
{

}

vertex EulerianGraph::search(int value)
{
	vertex v;
	v.key = -1;
	for(int i = 0; i < vertices.size(); i++)
	{
		if(vertices[i].key == value)
			return vertices[i];
	}
	return v;
}