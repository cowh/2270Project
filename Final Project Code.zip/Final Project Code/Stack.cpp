#include "Stack.hpp"

Stack::Stack()
{
	top = 0;
	maxSize = 100;
}

Stack::~Stack()
{

}

bool Stack::isFull()
{
	return top == maxSize;
}

bool Stack::isEmpty()
{
	return top == 0;
}

void Stack::push(vertex v)
{
	if(!isFull())
	{
		data[top] = v;
		top++;
	}
	else
		cout << "stack overflow" << endl;
}

vertex Stack::pop()
{
	vertex rm;
	if(!isEmpty())
	{
		top--;
		rm = data[top];
	}
	else
		cout << "stack underflow" << endl;
	return rm;
}