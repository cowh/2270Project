#include "Stack.cpp"

using namespace std;

int main()
{
	vertex v1;
	v1.name = "hello";
	vertex v2;
	v2.name = "world";
	vertex v3;
	v3.name = "!";
	Stack s;
	s.push(v1);
	s.push(v2);
	s.push(v3);
	vertex vv1 = s.pop();
	vertex vv2 = s.pop();
	vertex vv3 = s.pop();
	cout << vv3.name;
}