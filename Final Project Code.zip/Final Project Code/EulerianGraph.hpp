#include <iostream>
#include <vector>
using namespace std;
struct adjVertex;

struct vertex
{
	string name;
	std::vector<adjVertex> adj;
	bool visited;
	bool bridge;
	int distance;
	vertex *previous;
};

struct adjVertex
{
	vertex *v;
	int weight;
};

class EulerianGraph
{
private:
	std::vector<vertex> vertices;
protected:
public:
	void addVertex(string name);
	void addEdge(string startV, string endV, int weight);
	int countEdges();
	bool isConnected(string name);
	bool isEulerian(EulerianGraph g, int odd, string name);
	void printGraph(EulerianGraph g);
	void printEulerian();
	vertex search(string name);
};