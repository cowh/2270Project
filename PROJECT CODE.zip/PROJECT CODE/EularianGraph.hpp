#include <iostream>
#include <vector>

struct edge;

struct vertex
{
	int key;
	std::vector<edge> adj;
};

struct edge
{
	vertex *v;
	int weight;
};

class EulerianGraph
{
private:
	std::vector<vertex> vertices;
protected:
public:
	void addVertex(int value);
	void addEdge(int startV, int endV, int weight);
	void rmVertex(int value);
	void rmEdge(int startV, int endV);
	bool isEulerianPath();
	bool isEulerianCircuit();
	void printGraph();
	void printEulerian();
	vertex search(int value);
};