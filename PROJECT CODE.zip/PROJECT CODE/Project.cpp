#include "EulerianGraph.cpp"

using namespace std;

int main()
{

	/**********************************************************************
	***********************************************************************
	My project implements two data structures. The graph data structure 
	allows me to create different types of graphs & test them with my main
	method "isEularian". An Eulerian graph can be completely traversed 
	without touching each edge more than once. There are two types of graphs
	that satisfy the Eulerian graph type. An Eulerian Circuit & an Eularian
	path

	Eulerian Ciruit
	----------------------------------------------------------------------
	1. A each node in an Eulerian Cicuit must contain an even number of
	adjacent nodes.

	2. The graph must be connected. i.e. each node must have more than
	one adjacent node.
	----------------------------------------------------------------------


	Eulerian Path
	----------------------------------------------------------------------
	1. Exactly two nodes must contain an odd number of adjacent nodes. The
	rest of the nodes must have an even number of adjacent nodes.

	2. The graph must be connected. i.e. each node must have more than
	one adjacent node.
	----------------------------------------------------------------------

	~There are three test cases below. I have created an Eulerian Path, an
	Eulerian Circuit & one non-Eulerian graph for testing. Feel free to c-
	reate your own graph & test.
	it

	Enjoy! 😃
	***********************************************************************
	**********************************************************************/
	

	/**********************************************************************
	***********************************************************************

	GRAPH #1
	
	The graph below contains at least one Euler Path. This means that each
	node can be visited once while touching each edge exactly once

	

								A ---- F ---- T
							   / \ 	   |	 /
							  /   \    |	/
							 O -- B -- D   /
						      \   /	\  |  /
						       \ /	 \ | /
						        C ---- E 

	
	*************************************************************************
	************************************************************************/

	EulerianGraph g1;
	g1.addVertex("O");
	g1.addVertex("A");
	g1.addVertex("B");
	g1.addVertex("C");
	g1.addVertex("D");
	g1.addVertex("E");
	g1.addVertex("T");
	g1.addVertex("F");
	g1.addEdge("A","O",4);
	g1.addEdge("O","A",4);
	g1.addEdge("A","B",4);
	g1.addEdge("B","A",4);
	g1.addEdge("B","C",4);
	g1.addEdge("C","B",4);
	g1.addEdge("C","D",4);
	g1.addEdge("D","C",4);
	g1.addEdge("D","E",4);
	g1.addEdge("E","D",4);
	g1.addEdge("E","T",4);
	g1.addEdge("T","E",4);
	g1.addEdge("T","F",4);
	g1.addEdge("F","T",4);
	cout << "GRAPH #1" << endl;
	cout << "------------------------------" << endl;
	g1.printGraph(g1);
	int g1edges = g1.countEdges();
	g1.isEulerian(g1, g1edges, "O");
	cout << "------------------------------" << endl;
	cout << endl << endl << endl << endl;

	/**********************************************************************
	***********************************************************************

	GRAPH #2
	
	The graph below contains at least one Euler Circuit. This is a modified
	Even, slightly more Eulerian type of graph that satisfies the same con-
	ditions of the Euler Path graph, but this Euler Path starts and ends on
	the same node.
						
									
									A
								   / \
						E _______ /	  \	_______	B
						   \_____/	   \____/
								/\____/	\
							   / /	   \ \
							   D         C
	

	
	*************************************************************************
	************************************************************************/


	EulerianGraph g2;
	g2.addVertex("A");
	g2.addVertex("B");
	g2.addVertex("C");
	g2.addVertex("D");
	g2.addVertex("E");
	g2.addEdge("A","C",0);
	g2.addEdge("A","D",0);
	g2.addEdge("B","D",0);
	g2.addEdge("B","E",0);
	g2.addEdge("C","E",0);
	g2.addEdge("C","A",0);
	g2.addEdge("D","A",0);
	g2.addEdge("D","B",0);
	g2.addEdge("E","B",0);
	g2.addEdge("E","C",0);
	cout << "GRAPH #2" << endl << endl;
	cout << "-------------------------------" << endl;
	g2.printGraph(g2);
	int g2edges = g2.countEdges();
	g2.isEulerian(g2,g2edges, "A");
	cout << "-------------------------------" << endl;
	cout << endl << endl << endl << endl;

	/**********************************************************************
	***********************************************************************

	GRAPH #3
	
	The graph below gives an example of a graph that is not Eularian in any
	way. This means that no matter at which node you begin. You cannot tra-
	verse the graph in such a way that visits every node & touches each ed-
	ge exactly once.


								    B ----- E
								   / \	   / \
								  /	  \	  /	  \
								 /	   \ /	   \
								A       D       G
								 \     / \     /
								  \   /   \   /
								   \ /     \ /
								    C ----- F
	

	
	*************************************************************************
	************************************************************************/

	EulerianGraph g3;
	g3.addVertex("A");
	g3.addVertex("B");
	g3.addVertex("C");
	g3.addVertex("D");
	g3.addVertex("E");
	g3.addVertex("F");
	g3.addVertex("G");
	g3.addEdge("A","B",0);
	g3.addEdge("A","C",0);
	g3.addEdge("B","A",0);
	g3.addEdge("B","D",0);
	g3.addEdge("B","E",0);
	g3.addEdge("C","A",0);
	g3.addEdge("C","D",0);
	g3.addEdge("C","F",0);
	g3.addEdge("D","B",0);
	g3.addEdge("D","C",0);
	g3.addEdge("D","E",0);
	g3.addEdge("D","F",0);
	g3.addEdge("E","B",0);
	g3.addEdge("E","D",0);
	g3.addEdge("E","G",0);
	g3.addEdge("F","C",0);
	g3.addEdge("F","D",0);
	g3.addEdge("F","G",0);
	g3.addEdge("G","E",0);
	g3.addEdge("G","F",0);
	cout << "GRAPH #3" << endl;
	cout << "--------------------------" << endl;
	g3.printGraph(g3);
	int g3edges = g3.countEdges();
	g3.isEulerian(g3,g3edges, "A");
	cout << "--------------------------" << endl;

}