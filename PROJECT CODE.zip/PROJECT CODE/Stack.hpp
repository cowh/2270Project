#include <iostream>
#include <vector>

using namespace std;

class Stack
{
private:
	int top;
	int maxSize;
	vertex data[100];
protected:
public:
	Stack();
	~Stack();
	bool isFull();
	bool isEmpty();
	void push(vertex v);
	vertex pop();
};